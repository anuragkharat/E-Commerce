const bar = document.getElementById('bar');
const close = document.getElementById('close');
const nav = document.getElementById('navbar');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    })
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    })
}


// let preveiwContainer = document.querySelector('.pro-container');
// let preveiwBox = preveiwContainer.querySelectorAll('.pro');

// document.querySelectorAll('.section-p1 .des').forEach(product =>{
//     product.onclick = () =>{
//         let name = product.getAttribute('')
//     }
// })